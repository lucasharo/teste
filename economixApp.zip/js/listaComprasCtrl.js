angular.module('economix.listaComprasCtrl', [])

.controller('ListaComprasCtrl', function($scope, $ionicModal, $state, $filter, $rootScope, ListaComprasService, AutenticacaoService, FlashService) {
    
   	$rootScope.$on("$locationChangeStart", function(){
		if($rootScope.fgLoginGlicemia){
			clear();
			$rootScope.fgLoginGlicemia = false;
	   	}
	   
    	if($rootScope.location.$$path == "/tab/listaCompras"){
    		//init();
        }
    });
	
    var init = function(){
        AutenticacaoService.getCredentials(function(e, paciente){
    	    if(e){
    	        FlashService.erro(e);
    	    }else{
                $scope.paciente = {			
					usuario		: paciente.usuario,
                    glicemia: {					
						dtMedicao	: new Date(),
						medicoes		: [{
							dtMedicao	: "",
							medicao		: "",
							anotacao	: ""
						}],                   
        				periodo			: {
            				dtInicio	: new Date(),
            				dtFim		: new Date()
        				}
        			}        
    			}			    
    
    			$ionicModal.fromTemplateUrl('templates/modal-glicemia.html', {
    				scope: $scope,
    				animation: 'slide-in-up'
  					}).then(function(modal) {
    					$scope.modal = modal;
  				});
            }
    	}); 
    }
	
	var valores = [], labels = [];
    
    $scope.salvar = function(){
        var paciente = {
            usuario		: $scope.paciente.usuario,
            glicemia: {
                dtMedicao 	: $filter('date')($scope.paciente.glicemia.dtMedicao, 'yyyy-MM-dd'),
            	medicao		: $scope.paciente.glicemia.medicao,
            	anotacao	: $scope.paciente.glicemia.anotacao
        	}
        }
        
        ListaComprasService.salvar(paciente, function(e, resultado){
            if(e){
                FlashService.erro(e);
            }else{
                FlashService.sucesso(resultado);
				
        		$scope.grafico();
				
				$scope.paciente.glicemia.medicao = "";
            	$scope.paciente.glicemia.anotacao = "";
				
        		$scope.modal.hide();
            }
        });
    }
	
    $scope.grafico = function(){       
        var dtInicio = $filter('date')($scope.paciente.glicemia.periodo.dtInicio, 'yyyy-MM-dd');        
        var dtFim = $filter('date')($scope.paciente.glicemia.periodo.dtFim, 'yyyy-MM-dd');
        
		if($scope.paciente.glicemia.periodo.dtInicio > new Date()){
			FlashService.erro("Período inicial deve ser menor ou igual data atual.");
		}else if($scope.paciente.glicemia.periodo.dtInicio > $scope.paciente.glicemia.periodo.dtFim){
            FlashService.erro("Período inicial maior que o período final.");
        }else{
        	ListaComprasService.listarMedicoes($scope.paciente.usuario, function(e, medicoes){
            	if(e){
                	FlashService.erro(e);
            	}else{
                	if(medicoes) {						
						valores = [];
						labels = [];
						
						medicoes = $filter('orderBy')(medicoes, 'dtMed');
						
                      	for (var i = 0; i < medicoes.length; i++) {
							$scope.paciente.glicemia.medicoes[i] = {
								dtMedicao	: medicoes[i].dtMed,
								medicao		: medicoes[i].med,
								anotacao	: medicoes[i].note
							};
							
							if(dtInicio <= medicoes[i].dtMed && dtFim >= medicoes[i].dtMed){
								valores.push(medicoes[i].med);						
            					labels.push($filter('date')(medicoes[i].dtMed, 'dd-MM-yyyy'));
                      		}
						}
        				
						if(valores.length > 0){
                      		carregarGrafico();
						}else{
        					FlashService.erro("Nenhuma medição nesse período.");		
						}
                    }
            	}
        	});
        }
    }
	
	var carregarGrafico = function(){
			$("#chart").kendoChart({
				title: {
                	text: "Medições - " + $filter('date')($scope.paciente.glicemia.periodo.dtInicio, 'dd/MM/yyyy') + " - " + $filter('date')($scope.paciente.glicemia.periodo.dtFim, 'dd/MM/yyyy'),
              		font: "20px bold Arial,Helvetica,sans-serif"
				},
				theme: "Bootstrap",
				categoryAxis: {
                 			min: 0,
                 			max: 10,
                 			labels: {
                    				rotation: "auto"
                 			}
              		},
  				axisDefaults: {
    				categories: labels
  				},
  				series: [
    				{ data: valores }
  				],
				pannable: {
                 			lock: "y"
              		},
				seriesClick: medicaoModal
			});
	}
	
	$scope.showModal = function(){
		$scope.paciente.glicemia.medicao = "";
		$scope.paciente.glicemia.anotacao = "";
		
		$scope.modal.show();
	}
	
	function medicaoModal(e){
		for(var i = 0; i < $scope.paciente.glicemia.medicoes.length; i++){
			if($filter('date')($scope.paciente.glicemia.medicoes[i].dtMedicao, 'dd-MM-yyyy') == e.category){
				$scope.paciente.glicemia.dtMedicao = $scope.paciente.glicemia.medicoes[i].dtMedicao;
				$scope.paciente.glicemia.medicao = $scope.paciente.glicemia.medicoes[i].medicao;
				$scope.paciente.glicemia.anotacao = $scope.paciente.glicemia.medicoes[i].anotacao;
				
				$scope.modal.show();
				
				break;
			}
		}
	}
	
	var clear = function(){
		delete $scope.paciente;
		
		valores = [];
		labels = [];
	}
	
   // init();
})