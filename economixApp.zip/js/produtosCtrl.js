angular.module('economix.produtosCtrl', [])

.controller('ProdutosCtrl', function($scope, $rootScope, $state, $filter, $ionicModal, $cordovaSQLite, $cordovaDatePicker, DB, AutenticacaoService, ProdutosService, FlashService) {
    
    $rootScope.$on("$locationChangeStart", function(){
		if($rootScope.fgLoginPerfil){
			clear();
			$rootScope.fgLoginPerfil = false;
	   	}
		
        if($rootScope.location.$$path == "/tab/produtos"){
    		init();
        }
    });
    
    var init = function(){    
    	AutenticacaoService.getCredentials(function(e, paciente){
    	    if(e){
    	        FlashService.erro(e);
    	    }else{
                $scope.perfil = {
                	nome			: paciente.nome, 			
					usuario			: paciente.usuario,		
					email			: paciente.email,			
					sexo			: paciente.sexo, 			
					dtNascimento	: new Date(paciente.dtNascimento), 
					telefone		: paciente.telefone,		
					tipoDiabetes	: paciente.tipoDiabetes,	
					medico			: paciente.medico	
            	}
    	    }
    	}); 
		
    	$ionicModal.fromTemplateUrl('templates/modal-perfil.html', {
    		scope: $scope,
    		animation: 'slide-in-up'
  			}).then(function(modal) {
    			$scope.modal = modal;
  		});
    }
    
    $scope.editar = function(){
    	$scope.perfilAlterado = {
            nome			: $scope.perfil.nome, 			
			usuario			: $scope.perfil.usuario,		
			email			: $scope.perfil.email,			
			sexo			: $scope.perfil.sexo, 			
			dtNascimento	: new Date($scope.perfil.dtNascimento), 
			telefone		: $scope.perfil.telefone,
			tipoDiabetes	: $scope.perfil.tipoDiabetes,	
			medico			: $scope.perfil.medico	
        }
		
        $scope.modal.show();
    }
    
    $scope.salvar = function() {
        var pacienteAlterado = {
            nome			: $scope.perfilAlterado.nome, 			
			usuario			: $scope.perfilAlterado.usuario,		
			email			: $scope.perfilAlterado.email,			
			sexo			: $scope.perfilAlterado.sexo, 			
			dtNascimento	: new Date($scope.perfilAlterado.dtNascimento), 
			telefone		: $scope.perfilAlterado.telefone,		
			tipoDiabetes	: $scope.perfilAlterado.tipoDiabetes,	
			medico			: $scope.perfilAlterado.medico,
            senha			: $scope.perfilAlterado.senha
        }
        
    	ProdutosService.salvar(pacienteAlterado, function (e, resultado) {
                if (e) {
                    FlashService.erro(e);
                } else {
                    var pacienteSessao = {
                		nome			: $scope.perfilAlterado.nome, 			
						usuario			: $scope.perfilAlterado.usuario,		
						email			: $scope.perfilAlterado.email,			
						sexo			: $scope.perfilAlterado.sexo, 			
						dtNascimento	: new Date($scope.perfilAlterado.dtNascimento), 
						telefone		: $scope.perfilAlterado.telefone,		
						tipoDiabetes	: $scope.perfilAlterado.tipoDiabetes,	
						medico			: $scope.perfilAlterado.medico
            		}
                    
                    AutenticacaoService.setCredentials(pacienteSessao);
                    
                    init();
                    
    				delete $scope.perfilAlterado;
                    
        			$scope.modal.hide();
                    
                    FlashService.sucesso(resultado);
                }
            });
        }
	
	var clear = function(){
		delete $scope.perfil;
		delete $scope.perfilAlterado;
	}
    
    init();
})
