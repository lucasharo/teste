angular.module('economix.opcaoCtrl', [])

.controller('OpcaoCtrl', function($scope, OpcaoService, $ionicActionSheet) {
    $scope.show = function() {
   		$ionicActionSheet.show({
   		  buttons: [
   		    { text: '<b>Share</b> This' },
   		    { text: 'Move' }
   		  ],
   		  destructiveText: 'Delete',
   		  titleText: 'Modify your album',
   		  cancelText: 'Cancel',
   		  cancel: function() {
   		      history.go(-1);
   		     },
   		  buttonClicked: function(index) {
   		    return true;
   		  }
   		});
   	}
	
	$scope.clear = function(){
	}
});
