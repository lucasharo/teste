angular.module('economix.produtosService', [])

.service('ProdutosService', function($http, DB, Config, AjaxService) {
	
	return {
        salvar: function(paciente, callback) {		
			AjaxService.post('/atualizarPaciente', paciente, function(e, pacienteResultado){
				if(e){
                	callback(e);
				}else{
					callback(null, "Perfil atualizado com sucesso!");
				}
			});
        }
    }
})