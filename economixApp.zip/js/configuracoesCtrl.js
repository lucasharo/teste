angular.module('economix.configuracoesCtrl', [])

.controller('ConfiguracoesCtrl', function($scope, $rootScope, $cordovaLocalNotification, ConfiguracoesService) {
	
	$scope.scheduleDelayedNotification = function () {
      var now = new Date().getTime();
      var teste = new Date(now + 5 * 1000);
      $cordovaLocalNotification.schedule({
        id: 1,
        title: teste,
        text: teste,
		every: "week",
        at: teste
      }).then(function (result) {
      });
    };
	
	$scope.clear = function(){		
	}
     
});
    
    
