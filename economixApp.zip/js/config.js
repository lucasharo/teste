angular.module('economix.config', [])

.constant('Config', {
    ambiente:{
        urlServer: "https://glicoipro.mybluemix.net"
    },
	toast:{
		duration: "short",
        position: "bottom"
    },
    db: {
    	nameDB: 'economix.db',
    	tables: [
    	  {
    	        name: 'sessao',
    	        columns: [
    	            {name: 'nome', 			type: 'text'},
                    {name: 'usuario',		type: 'text'},
                    {name: 'email',			type: 'text'},
                    {name: 'sexo', 			type: 'number'},
                    {name: 'dtNascimento', 	type: 'text'},
                    {name: 'telefone',		type: 'text'},
                    {name: 'tipoDiabetes',	type: 'number'},
                    {name: 'medico',		type: 'text'},
    	        ]
    	    }
    	]
    }
})