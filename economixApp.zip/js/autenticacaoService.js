angular.module('economix.autenticacaoService', [])

.service('AutenticacaoService', function($http, $rootScope, $state, $filter, $ionicPopup, DB, Config, AjaxService) {
    var base64 = {
        
        keyStr: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=',
        
        encode: function (input) {
            var output = "";
            var chr1, chr2, chr3 = "";
            var enc1, enc2, enc3, enc4 = "";
            var i = 0;
            
            do {
                chr1 = input.charCodeAt(i++);
                chr2 = input.charCodeAt(i++);
                chr3 = input.charCodeAt(i++);
                
                enc1 = chr1 >> 2;
                enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
                enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
                enc4 = chr3 & 63;
                
                if (isNaN(chr2)) {
                    enc3 = enc4 = 64;
                } else if (isNaN(chr3)) {
                    enc4 = 64;
                }
                
                output = output +
                    this.keyStr.charAt(enc1) +
                    this.keyStr.charAt(enc2) +
                    this.keyStr.charAt(enc3) +
                    this.keyStr.charAt(enc4);
                chr1 = chr2 = chr3 = "";
                enc1 = enc2 = enc3 = enc4 = "";
            } while (i < input.length);
            
            return output;
        },
        
        decode: function (input) {
            var output = "";
            var chr1, chr2, chr3 = "";
            var enc1, enc2, enc3, enc4 = "";
            var i = 0;
            
            // remove all characters that are not A-Z, a-z, 0-9, +, /, or =
            var base64test = /[^A-Za-z0-9\+\/\=]/g;
            if (base64test.exec(input)) {
                window.alert("There were invalid base64 characters in the input text.\n" +
                    "Valid base64 characters are A-Z, a-z, 0-9, '+', '/',and '='\n" +
                    "Expect errors in decoding.");
            }
            input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
            
            do {
                enc1 = this.keyStr.indexOf(input.charAt(i++));
                enc2 = this.keyStr.indexOf(input.charAt(i++));
                enc3 = this.keyStr.indexOf(input.charAt(i++));
                enc4 = this.keyStr.indexOf(input.charAt(i++));
                
                chr1 = (enc1 << 2) | (enc2 >> 4);
                chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
                chr3 = ((enc3 & 3) << 6) | enc4;
                
                output = output + String.fromCharCode(chr1);
                
                if (enc3 != 64) {
                    output = output + String.fromCharCode(chr2);
                }
                if (enc4 != 64) {
                    output = output + String.fromCharCode(chr3);
                }
                
                chr1 = chr2 = chr3 = "";
                enc1 = enc2 = enc3 = enc4 = "";

            } while (i < input.length);
            
            return output;
        }
    }
    
    return{
        verificarUsuario: function() {
            DB.getLast("sessao").then(function(result){    	
        		if(result.rows.length > 0){                
            		var paciente = DB.fetch(result);
                
            		var authdata = base64.encode(paciente.usuario + ':' + paciente.senha);             
                
                	$http.defaults.headers.common['Authorization'] = 'Basic ' + authdata;                
        		}
				
            	if (paciente) {
              		$http.defaults.headers.common['Authorization'] = 'Basic ' + authdata;
                	if(!($rootScope.location.$$path == "/login" || $rootScope.location.$$path == "/cadastro" || $rootScope.location.$$path == "/gerarSenha")){
                    	$state.go($rootScope.location.$$path.substring(1));
                	}else{
                		$state.go("tab.produtos");
                	}
            	} else {
					//$state.go("tab.promocoes");
					if(!($rootScope.location.$$path == "/login" || $rootScope.location.$$path == "/cadastro" || $rootScope.location.$$path == "/gerarSenha")){
                    	$state.go("login");
                	}else{                		
                		$state.go($rootScope.location.$$path.substring(1));
					}
                	
            	}                   
        	});
        },
    	login: function(paciente, callback) {
			AjaxService.post('/loginPaciente', paciente, function(e, pacienteResultado){
				if(e){
                	callback(e);
				}else{
					callback(null, pacienteResultado);
				}
			});
        },
        cadastrar: function(paciente, callback) {
			AjaxService.post('/cadastrarPaciente', paciente, function(e, pacienteResultado){
				if(e){
                	callback(e);
				}else{
					callback(null, "Cadastro efetuado com sucesso!");
				}
			});
        },
        gerarNovaSenha: function(paciente, callback) {			
			AjaxService.post('/gerarNovaSenhaPaciente', paciente, function(e, pacienteResultado){
				if(e){
                	callback(e);
				}else{
					callback(null, "Uma nova senha foi enviada para seu email.");
				}
			});
        },
        setCredentials: function(paciente) {            
            var pacienteSessao = {
                nome			: paciente.nome, 			
				usuario			: paciente.usuario,		
				email			: paciente.email,			
				sexo			: paciente.sexo, 			
				dtNascimento	: new Date(paciente.dtNascimento), 
				telefone		: paciente.telefone,		
				tipoDiabetes	: paciente.tipoDiabetes,	
				medico			: paciente.medico	
            }
            
            DB.insert("sessao", pacienteSessao);
        },        
        clearCredentials: function() {			
            DB.deleteAll("sessao");
			
            $state.go('login');
        },
        getCredentials: function(callback){
            DB.getLast("sessao").then(function(result){    	
        		if(result.rows.length > 0){
            		callback(null, DB.fetch(result));                
            	}else{               
            		callback("Erro ao consultar perfil.");
            	}
        });
        }
         
    }
})