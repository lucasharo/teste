angular.module('economix.configuracoesService', [])

.service('ConfiguracoesService', function() {
})