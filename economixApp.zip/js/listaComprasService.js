angular.module('economix.listaComprasService', [])

.service('ListaComprasService', function($http, DB, Config, AjaxService) {   
  
	return {
		listarMedicoes: function(usuario, callback){           
			AjaxService.get('/listarMedicoes', usuario, function(e, medicoes){
				if(e){
                	callback(e);
				}else{
					callback(null, medicoes.meds);
				}
			});
		},
        salvar: function(paciente, callback){
			AjaxService.post('/adicionarMedicao', paciente, function(e, pacienteResultado){
				if(e){
                	callback(e);
				}else{
					callback(null, "Medição adicionada com sucesso!");
				}
			});
        }
	}
})