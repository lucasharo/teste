angular.module('economix.autenticacaoCtrl', [])

.controller('AutenticacaoCtrl', function($scope, $state, $filter, $rootScope, $ionicModal, $cordovaOauth, AutenticacaoService, FlashService, $http) {    
   
	$scope.paciente = {}
   
   $ionicModal.fromTemplateUrl('templates/modal-cadastro.html', {
    	scope: $scope,
    	animation: 'slide-in-up'
  		}).then(function(modal) {
    		$scope.modalCadastro = modal;
  	});
    
    $ionicModal.fromTemplateUrl('templates/modal-gerarSenha.html', {
    	scope: $scope,
    	animation: 'slide-in-up'
  		}).then(function(modal) {
    		$scope.modalGerarSenha = modal;
  	});
	
	$scope.facebookLogin = function() {
       $cordovaOauth.facebook("941070239280279", ["email", "user_website", "user_location", "user_relationships"]).then(function(result1) {
            alert(result1.access_token);
		   $http.get("https://graph.facebook.com/v2.5/me", { params: { access_token: result1.accessToken, fields: "id,name,gender,location,website,picture,relationship_status", format: "json" }}).then(function(result) {
                alert(JSON.stringify(result.data));
            }, function(error) {
                alert("There was a problem getting your profile.  Check the logs for details.");
                console.log(error);
            });
        }, function(error) {
            alert("There was a problem signing in!  See the console for logs");
            console.log(error);
        });
    }
	
	
	function teste(access_token)
{
    $http.get("https://graph.facebook.com/v2.5/me", {params: {access_token: access_token, fields: "name,gender,location,picture", format: "json" }}).then(function(result) {
        alert(JSON.stringify(result));
    }, function(error) {
        alert("Error: " + JSON.stringify(error));
    });
}
    
    $scope.login = function() {
    	AutenticacaoService.login($scope.paciente, function (e, paciente) {
			if(e){
               	FlashService.erro(e);
           	}else{
           		var pacienteSessao = {
        	        nome : paciente.nome,
                    usuario : paciente.usuario,
                    email : paciente.email,
                    sexo : paciente.sexo,
                    dtNascimento : new Date(paciente.dtNascimento),
                    telefone : paciente.telefone,
                    tipoDiabetes : paciente.tipoDiabetes,
                    medico : paciente.medico,
                }
			   
			   	AutenticacaoService.setCredentials(pacienteSessao);
				
				$scope.paciente = {}
                
				$rootScope.fgLoginGlicemia = true;
				$rootScope.fgLoginPerfil = true;
				$rootScope.fgLoginMedico = true;
				
                $state.go('tab.produtos');
            }
        });
    }    
    
    $scope.cadastrar = function() {
			var paciente = {
        	   	nome : $scope.paciente.nome,
               	usuario : $scope.paciente.usuario,
               	email : $scope.paciente.email,
               	sexo : $scope.paciente.sexo,
               	dtNascimento : new Date($scope.paciente.dtNascimento),
               	telefone : $scope.paciente.telefone,
               	tipoDiabetes : $scope.paciente.tipoDiabetes,
				senha: $scope.paciente.senha,
               	medico : ""
            }
			
            AutenticacaoService.cadastrar(paciente, function (e, resultado) {
				if(e){
					FlashService.erro(e);
				}else{
                    var pacienteSessao = {
                        nome: $scope.paciente.nome,
                        usuario: $scope.paciente.usuario,
                        email: $scope.paciente.email,
                        sexo: $scope.paciente.sexo,
                        dtNascimento: new Date($scope.paciente.dtNascimento),
                        telefone: $scope.paciente.telefone,
                        tipoDiabetes: $scope.paciente.tipoDiabetes,
                        medico: $scope.paciente.medico
                    }
                    
                    AutenticacaoService.setCredentials(pacienteSessao);
					
					$scope.paciente = {}
					
                    $scope.modalCadastro.hide();
					
                    FlashService.sucesso(resultado, true);
					
                    $state.go('tab.produtos');
                }
            });
        }

	$scope.gerarNovaSenha = function() {
		var paciente = {
        	email: $scope.paciente.email
        }			
		
		AutenticacaoService.gerarNovaSenha(paciente, function (e, resultado) {
            if (e) {
            	FlashService.erro(e);
            } else {
            	FlashService.sucesso(resultado);
					
				$scope.modalGerarSenha.hide();
        	}
    	});
	}
});
    
    
