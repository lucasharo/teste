angular.module('economix.promocoesService', [])

.service('PromocoesService', function($http, Config, AjaxService) {
    return {
		listarMedicos: function(callback){
			AjaxService.get('/listarMedicos', "", function(e, medicoResultado){
				if(e){
                	callback(e);
				}else{
					callback(null, medicoResultado);
				}
			});
        },
        medicoUsuario: function(medico, callback){
			AjaxService.get('/medicoUsuario', medico, function(e, medicoResultado){
				if(e){
                	callback(e);
				}else{
					callback(null, medicoResultado);
				}
			});
        }
	}
})
