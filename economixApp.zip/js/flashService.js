angular.module('economix.flashService', [])

.service('FlashService', function(toastr) {
		
    return{
        sucesso: function(mensagem) {
			toastr.success(mensagem);			
        },
        erro: function(mensagem) {
			toastr.error(mensagem);
        }
    }
})