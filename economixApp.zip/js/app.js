angular.module('economix', ['ionic', 'ngCordova', 'economix.ngUnique', 'ui.utils.masks', 'toastr', 'filtros', 'economix.produtosCtrl', 'economix.listaComprasCtrl', 'economix.promocoesCtrl', 'economix.configuracoesCtrl', 'economix.opcaoCtrl', 'economix.autenticacaoCtrl',
                           'economix.produtosService', 'economix.listaComprasService', 'economix.promocoesService', 'economix.configuracoesService', 'economix.opcaoService', 'economix.autenticacaoService', 'economix.flashService',
                          'economix.db', 'economix.config', 'economix.ajaxService'])

.run(function($ionicPlatform, DB, $rootScope, $location, AutenticacaoService, $ionicPopup) {
  $ionicPlatform.ready(function() {
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);
    }
    if (window.StatusBar) {
      StatusBar.styleLightContent();
    }      
      
    DB.init();
      
    $rootScope.location = $location;
	
	$rootScope.fgLoginGlicemia = false;
	$rootScope.fgLoginPerfil = false;
	$rootScope.fgLoginMedico = false;
    
    AutenticacaoService.verificarUsuario();
      
    $rootScope.$on("$locationChangeStart", function(){
    	AutenticacaoService.verificarUsuario();   
    });
          
      $rootScope.logout = function(){
          $ionicPopup.confirm({
                                                title: 'Encerrar sessão',
                                                template: 'Deseja realmente sair?',
                                               	buttons: [{ 
                                                	text: 'Não',
                                                 	type: 'button-positive'
                                                },
   												{
     												text: 'Sim',
     												type: 'button-default',
     												onTap: function() {
            										AutenticacaoService.clearCredentials();
													}
   												}
  											]
                                           });
      }
      
      $ionicPlatform.registerBackButtonAction(function () {
                                            $ionicPopup.confirm({
                                                title: 'Fechar aplicativo',
                                                template: 'Deseja realmente fechar o aplicativo?',
                                               	buttons: [{ 
                                                	text: 'Não',
                                                 	type: 'button-positive'
                                                },
   												{
     												text: 'Sim',
     												type: 'button-default',
     												onTap: function() {ionic.Platform.exitApp();}
   												}
  											]
                                           });
                                             

	}, 100);
    										});
})

.config(function($stateProvider, $urlRouterProvider, toastrConfig) {

  $stateProvider
  
  .state('login', {
    url: '/login',
    templateUrl: 'templates/login.html',
    controller: 'AutenticacaoCtrl'
  })
  .state('tab', {
    url: '/tab',
    abstract: true,
    templateUrl: 'templates/tabs.html'
  })
  .state('tab.produtos', {
    url: '/produtos',
    views: {
      'tab-produtos': {
        templateUrl: 'templates/tab-produtos.html',
        controller: 'ProdutosCtrl'
      }
    }
  })
  .state('tab.listaCompras', {
    url: '/listaCompras',
    views: {
      'tab-listaCompras': {
        templateUrl: 'templates/tab-listaCompras.html',
        controller: 'ListaComprasCtrl'
      }
    }
  })
  .state('tab.promocoes', {
    url: '/promocoes',
    views: {
      'tab-promocoes': {
        templateUrl: 'templates/tab-promocoes.html',
        controller: 'PromocoesCtrl'
      }
    }
  })
  .state('tab.detalhe', {
    url: '/produtos/detalhe',
    views: {
      'tab-produtos': {
        templateUrl: 'templates/produtoDetalhado.html',
        controller: 'PromocoesCtrl'
      }
    }
  })
  .state('tab.configuracoes', {
    url: '/configuracoes',
    views: {
      'tab-configuracoes': {
        templateUrl: 'templates/tab-configuracoes.html',
        controller: 'ConfiguracoesCtrl'
      }
    }
  })
  .state('tab.opcao', {
    url: '/opcao',
    views: {
      'tab-opcao': {
        templateUrl: 'templates/tab-opcao.html',
        controller: 'OpcaoCtrl'
      }
    }
  })
  .state('tab.ajuda', {
    url: '/opcao/ajuda',
    views: {
      'tab-opcao': {
        templateUrl: 'templates/ajuda.html',
        controller: 'OpcaoCtrl'
      }
    }
  })
  .state('tab.dicas', {
    url: '/opcao/dicas',
    views: {
      'tab-opcao': {
        templateUrl: 'templates/dicas.html',
        controller: 'OpcaoCtrl'
      }
    }
  })
  .state('tab.sobre', {
    url: '/opcao/sobre',
    views: {
      'tab-opcao': {
        templateUrl: 'templates/sobre.html',
        controller: 'OpcaoCtrl'
      }
    }
  });

  $urlRouterProvider.otherwise('login');
	
  	angular.extend(toastrConfig, {
    	containerId: 'toast-container',
    	maxOpened: 0,
    	positionClass: 'toast-bottom-full-width',
		progressBar: false,
    	preventDuplicates: false,
    	preventOpenDuplicates: false
  });
})