angular.module('economix.opcaoService', [])

.service('OpcaoService', function() {
    
	return {
		grafico: function(){
			
		}
	}
});
