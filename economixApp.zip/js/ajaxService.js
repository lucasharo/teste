angular.module('economix.ajaxService', [])

.service('AjaxService', function($http, $ionicLoading, Config) {
	
	var loadShow = function(){		
		$ionicLoading.show({
    		content: 'Loading',
    		animation: 'fade-in',
    		showBackdrop: true,
    		maxWidth: 200,
    		showDelay: 0
  		});
	}
	
	var loadHide = function(){
		$ionicLoading.hide();
	}
	
    return{
        post: function(url, data, callback) {
			loadShow();
			
            $http.post(Config.ambiente.urlServer + url, data)
  					.then(function (resultado) {				
				loadHide();
				
                callback(null, resultado.data);
            }, function (erro) {
				if (erro.status == 404){
                    erro.data = "Erro ao realizar comunicação com o servidor.";
				}
                else if (!erro.data){
                    erro.data = "Erro ao realizar comunicação com o servidor, verifique sua conexão com a internet.";
				}
				
				loadHide();
				
                callback(erro.data);
            });
        },
		get: function(url, data, callback) {
			loadShow();
			
            $http.get(Config.ambiente.urlServer + url + '/' + data)
  					.then(function (resultado) {				
				loadHide();
				
                callback(null, resultado.data);
            }, function (erro) {
                if (erro.status == 404){
                    erro.data = "Erro ao realizar comunicação com o servidor.";
				}
                else if (!erro.data){
                    erro.data = "Erro ao realizar comunicação com o servidor, verifique sua conexão com a internet.";
				}
				
				loadHide();
				
                callback(erro.data);
            });
        }
        }
})